import test from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import sharp from 'sharp';

import { unzipTextFromBase64 } from '../src/zip.js';
import { buildTtsAudioMessage, executeCommand, normalizePhoneNumber } from '../src/index.js';

async function createSolidImage(color) {
  return sharp({
    create: {
      width: 120,
      height: 120,
      channels: 3,
      background: color,
    },
  }).jpeg().toBuffer();
}

test('accepts dot-prefixed numeric location commands', async () => {
  const reply = await executeCommand('.33', {
    commandPrefix: '!',
    http: {
      async get() {
        return {
          data: {
            success: true,
            data: [
              {
                code: 'R1',
                name: 'Route 1',
                shift: 'AM',
                deliveryPoints: [
                  {
                    code: '33',
                    name: 'Stop 33',
                  },
                ],
              },
            ],
          },
        };
      },
    },
  });

  assert.equal(reply.type, 'location');
  assert.equal(reply.point.code, '33');
});

test('accepts slash-prefixed commands as an alias for dot commands', async () => {
  const reply = await executeCommand('/ping', {
    commandPrefix: '.',
  });

  assert.equal(reply, 'Bot aktif.');
});

test('builds tts audio payload', () => {
  const payload = buildTtsAudioMessage(Buffer.from('fake-mp3'));

  assert.equal(payload.mimetype, 'audio/mpeg');
  assert.equal(payload.ptt, false);
  assert.ok(Buffer.isBuffer(payload.audio));
});

test('normalizes phone numbers for pairing', () => {
  assert.equal(normalizePhoneNumber('+60 12-345 6789'), '60123456789');
});

test('custom command responds when trigger is prefixed', async () => {
  const reply = await executeCommand('.promo', {
    commandPrefix: '.',
    http: {
      async get(url) {
        if (url === '/api/custom-commands') {
          return {
            data: {
              success: true,
              data: [
                {
                  id: 'c1',
                  trigger: '.promo',
                  title: 'Promo',
                  contentType: 'text',
                  message: 'Promo hari ini',
                  mediaUrl: '',
                  fileName: '',
                  buttons: [],
                },
              ],
            },
          };
        }

        throw new Error(`unexpected url: ${url}`);
      },
    },
  });

  assert.equal(reply.type, 'custom-command');
  assert.equal(reply.message, 'Promo hari ini');
});

test('custom command responds when trigger is saved without prefix', async () => {
  const reply = await executeCommand('.promo', {
    commandPrefix: '.',
    http: {
      async get(url) {
        if (url === '/api/custom-commands') {
          return {
            data: {
              success: true,
              data: [
                {
                  id: 'c2',
                  trigger: 'promo',
                  title: 'Promo',
                  contentType: 'text',
                  message: 'Promo tanpa prefix',
                  mediaUrl: '',
                  fileName: '',
                  buttons: [],
                },
              ],
            },
          };
        }

        throw new Error(`unexpected url: ${url}`);
      },
    },
  });

  assert.equal(reply.type, 'custom-command');
  assert.equal(reply.message, 'Promo tanpa prefix');
});

test('wlink command returns a WhatsApp link with copy payload', async () => {
  const reply = await executeCommand('.wlink 60177501997', {
    commandPrefix: '.',
  });

  assert.equal(reply.type, 'text-with-copy');
  assert.equal(reply.copyText, 'https://wa.me/60177501997');
  assert.match(reply.text, /https:\/\/wa\.me\/60177501997/i);
});

test('timezone command shows current timezone', async () => {
  const reply = await executeCommand('.timezone', {
    commandPrefix: '.',
    getTimeZone() {
      return 'Asia/Kuala_Lumpur';
    },
  });

  assert.match(String(reply), /Timezone semasa: Asia\/Kuala_Lumpur/i);
});

test('timezone command sets a valid timezone', async () => {
  let selectedTimeZone = 'Asia/Kuala_Lumpur';
  const reply = await executeCommand('.timezone Asia/Jakarta', {
    commandPrefix: '.',
    getTimeZone() {
      return selectedTimeZone;
    },
    setTimeZone(nextValue) {
      selectedTimeZone = nextValue;
      return true;
    },
  });

  assert.equal(selectedTimeZone, 'Asia/Jakarta');
  assert.match(String(reply), /Timezone berjaya ditetapkan ke: Asia\/Jakarta/i);
});

test('timezone command rejects invalid timezone values', async () => {
  let calls = 0;
  const reply = await executeCommand('.timezone Mars/Phobos', {
    commandPrefix: '.',
    setTimeZone() {
      calls += 1;
      return true;
    },
  });

  assert.equal(calls, 0);
  assert.match(String(reply), /Timezone tidak sah/i);
});

test('timesolat command enables reminder for current personal chat', async () => {
  const state = {
    enabledChats: {},
    lastSentByChat: {},
  };

  const reply = await executeCommand('.timesolat on', {
    commandPrefix: '.',
    chatJid: '60123456789@s.whatsapp.net',
    getPrayerReminderConfig() {
      return state;
    },
    setPrayerReminderConfig(nextValue) {
      state.enabledChats = { ...nextValue.enabledChats };
      state.lastSentByChat = { ...nextValue.lastSentByChat };
      return true;
    },
  });

  assert.equal(state.enabledChats['60123456789@s.whatsapp.net'], true);
  assert.match(String(reply), /Timesolat ON/i);
});

test('timesolat command enables reminder for current group only', async () => {
  const state = {
    enabledChats: {},
    lastSentByChat: {},
  };

  const groupReply = await executeCommand('.timesolat on', {
    commandPrefix: '.',
    chatJid: '120363111111111111@g.us',
    getPrayerReminderConfig() {
      return state;
    },
    setPrayerReminderConfig(nextValue) {
      state.enabledChats = { ...nextValue.enabledChats };
      state.lastSentByChat = { ...nextValue.lastSentByChat };
      return true;
    },
  });

  const personalStatus = await executeCommand('.timesolat status', {
    commandPrefix: '.',
    chatJid: '60198765432@s.whatsapp.net',
    getPrayerReminderConfig() {
      return state;
    },
  });

  assert.equal(state.enabledChats['120363111111111111@g.us'], true);
  assert.equal(state.enabledChats['60198765432@s.whatsapp.net'], undefined);
  assert.match(String(groupReply), /group ini/i);
  assert.match(String(personalStatus), /OFF/i);
});

test('timesolat command disables reminder for current chat', async () => {
  const state = {
    enabledChats: {
      '60123456789@s.whatsapp.net': true,
    },
    lastSentByChat: {
      '60123456789@s.whatsapp.net': {
        date: '2026-07-25',
        prayers: ['Fajr'],
      },
    },
  };

  const reply = await executeCommand('.timesolat off', {
    commandPrefix: '.',
    chatJid: '60123456789@s.whatsapp.net',
    getPrayerReminderConfig() {
      return state;
    },
    setPrayerReminderConfig(nextValue) {
      state.enabledChats = { ...nextValue.enabledChats };
      state.lastSentByChat = { ...nextValue.lastSentByChat };
      return true;
    },
  });

  assert.equal(state.enabledChats['60123456789@s.whatsapp.net'], undefined);
  assert.equal(state.lastSentByChat['60123456789@s.whatsapp.net'], undefined);
  assert.match(String(reply), /Timesolat OFF/i);
});

test('zip command can read quoted chat text', async () => {
  const reply = await executeCommand('.zip', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  }, {
    extendedTextMessage: {
      contextInfo: {
        quotedMessage: {
          conversation: 'Halo dunia dari reply',
        },
      },
    },
  });

  assert.equal(reply.type, 'zip-text');
  assert.equal(unzipTextFromBase64(reply.payload), 'Halo dunia dari reply');
});

test('zip command can read quoted media caption', async () => {
  const reply = await executeCommand('.zip', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  }, {
    imageMessage: {
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            caption: 'Teks dari media',
          },
        },
      },
    },
  });

  assert.equal(reply.type, 'zip-text');
  assert.equal(unzipTextFromBase64(reply.payload), 'Teks dari media');
});

test('zip command can archive multiple media attachments', async () => {
  const currentImage = await createSolidImage({ r: 0, g: 0, b: 255 });
  const quotedImage = await createSolidImage({ r: 255, g: 0, b: 0 });

  const reply = await executeCommand('.zip', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer(media) {
      if (media?.url === 'current-image') return currentImage;
      if (media?.url === 'quoted-image') return quotedImage;
      return null;
    },
  }, {
    imageMessage: {
      url: 'current-image',
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            url: 'quoted-image',
          },
        },
      },
    },
  });

  assert.equal(reply.type, 'zip-file');
  assert.ok(Buffer.isBuffer(reply.document));

  const zip = await JSZip.loadAsync(reply.document);
  assert.deepEqual(Object.keys(zip.files).sort(), ['quoted-image-2.jpg', 'quoted-image.jpg']);
});

test('pdf command includes current and quoted images on separate pages', async () => {
  const currentImage = await createSolidImage({ r: 0, g: 128, b: 255 });
  const quotedImage = await createSolidImage({ r: 255, g: 128, b: 0 });

  const reply = await executeCommand('.pdf', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer(media) {
      if (media?.url === 'current-image') return currentImage;
      if (media?.url === 'quoted-image') return quotedImage;
      return null;
    },
  }, {
    imageMessage: {
      url: 'current-image',
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            url: 'quoted-image',
          },
        },
      },
    },
  });

  assert.equal(reply.type, 'document');
  assert.equal(reply.mimetype, 'application/pdf');
  assert.ok(Buffer.isBuffer(reply.document));

  const pdfText = reply.document.toString('latin1');
  const pageMatches = pdfText.match(/\/Type \/Page\b/g) || [];
  assert.equal(pageMatches.length, 2);
});

test('grid command builds a single-tile image when one image is provided', async () => {
  const sourceImage = await sharp({
    create: {
      width: 120,
      height: 120,
      channels: 3,
      background: { r: 0, g: 0, b: 255 },
    },
  }).jpeg().toBuffer();

  const reply = await executeCommand('.grid', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer(media) {
      if (media?.url === 'current-image') return sourceImage;
      return null;
    },
  }, {
    imageMessage: {
      caption: '.grid',
      url: 'current-image',
    },
  });

  assert.equal(reply.type, 'image-grid');
  assert.ok(Buffer.isBuffer(reply.imageBuffer));
  assert.equal(reply.mimetype, 'image/jpeg');
  assert.equal(reply.caption, undefined);

  const meta = await sharp(reply.imageBuffer).metadata();
  assert.equal(meta.width, 720);
  assert.equal(meta.height, 720);
});

test('grid command combines current and quoted image side by side', async () => {
  const imageA = await sharp({
    create: {
      width: 120,
      height: 120,
      channels: 3,
      background: { r: 0, g: 255, b: 0 },
    },
  }).jpeg().toBuffer();

  const imageB = await sharp({
    create: {
      width: 120,
      height: 120,
      channels: 3,
      background: { r: 255, g: 0, b: 0 },
    },
  }).jpeg().toBuffer();

  const reply = await executeCommand('.grid', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer(media) {
      if (media?.url === 'image-a') return imageA;
      if (media?.url === 'image-b') return imageB;
      return null;
    },
  }, {
    imageMessage: {
      caption: '.grid',
      url: 'image-a',
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            url: 'image-b',
          },
        },
      },
    },
  });

  assert.equal(reply.type, 'image-grid');
  assert.ok(Buffer.isBuffer(reply.imageBuffer));

  const meta = await sharp(reply.imageBuffer).metadata();
  assert.equal(meta.width, 1440);
  assert.equal(meta.height, 720);
});

test('grid command combines 3 images with two on top and one at bottom', async () => {
  const imageA = await createSolidImage({ r: 0, g: 255, b: 255 });
  const imageB = await createSolidImage({ r: 255, g: 255, b: 0 });
  const imageC = await createSolidImage({ r: 255, g: 0, b: 255 });

  const reply = await executeCommand('.grid', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer(media) {
      if (media?.url === 'image-a') return imageA;
      if (media?.url === 'image-b') return imageB;
      if (media?.url === 'image-c') return imageC;
      return null;
    },
  }, {
    imageMessage: {
      caption: '.grid',
      url: 'image-a',
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            url: 'image-b',
            contextInfo: {
              quotedMessage: {
                imageMessage: {
                  url: 'image-c',
                },
              },
            },
          },
        },
      },
    },
  });

  assert.equal(reply.type, 'image-grid');
  assert.ok(Buffer.isBuffer(reply.imageBuffer));

  const meta = await sharp(reply.imageBuffer).metadata();
  assert.equal(meta.width, 1440);
  assert.equal(meta.height, 1440);
});

test('grid command keeps rendering when more than six images are supplied', async () => {
  const imageBuffers = await Promise.all([
    { r: 0, g: 0, b: 0 },
    { r: 32, g: 32, b: 32 },
    { r: 64, g: 64, b: 64 },
    { r: 96, g: 96, b: 96 },
    { r: 128, g: 128, b: 128 },
    { r: 160, g: 160, b: 160 },
    { r: 192, g: 192, b: 192 },
  ].map((color) => createSolidImage(color)));

  const [imageA, imageB, imageC, imageD, imageE, imageF, imageG] = imageBuffers;

  const reply = await executeCommand('.grid', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer(media) {
      const bufferMap = {
        'image-a': imageA,
        'image-b': imageB,
        'image-c': imageC,
        'image-d': imageD,
        'image-e': imageE,
        'image-f': imageF,
        'image-g': imageG,
      };
      return bufferMap[media?.url] || null;
    },
  }, {
    imageMessage: {
      caption: '.grid',
      url: 'image-a',
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            url: 'image-b',
            contextInfo: {
              quotedMessage: {
                imageMessage: {
                  url: 'image-c',
                  contextInfo: {
                    quotedMessage: {
                      imageMessage: {
                        url: 'image-d',
                        contextInfo: {
                          quotedMessage: {
                            imageMessage: {
                              url: 'image-e',
                              contextInfo: {
                                quotedMessage: {
                                  imageMessage: {
                                    url: 'image-f',
                                    contextInfo: {
                                      quotedMessage: {
                                        imageMessage: {
                                          url: 'image-g',
                                        },
                                      },
                                    },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  });

  assert.equal(reply.type, 'image-grid');
  assert.ok(Buffer.isBuffer(reply.imageBuffer));

  const meta = await sharp(reply.imageBuffer).metadata();
  assert.equal(meta.width, 1440);
  assert.equal(meta.height, 2880);
});

test('grid command asks for image with caption when current image is missing', async () => {
  const reply = await executeCommand('.grid', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.match(String(reply), /hantar gambar/i);
});

test('sticker command asks to reply media when no quoted media', async () => {
  const reply = await executeCommand('.sticker', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async buildStickerCommandReply() {
      throw new Error('should not be called');
    },
  });

  assert.match(reply, /Reply gambar\/video/i);
});

test('sticker command passes nobg flag to sticker builder', async () => {
  const calls = [];
  const reply = await executeCommand('.sticker nobg', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async buildStickerCommandReply(mediaBuffer, options) {
      calls.push({ mediaBuffer, options });
      return {
        type: 'sticker',
        stickerBuffer: Buffer.from('fake-webp'),
      };
    },
    async downloadQuotedMediaBuffer() {
      return Buffer.from('fake-image');
    },
  }, {
    extendedTextMessage: {
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            url: 'https://example.com/photo.jpg',
          },
        },
      },
    },
  });

  assert.equal(reply.type, 'sticker');
  assert.ok(Buffer.isBuffer(reply.stickerBuffer));
  assert.equal(calls.length, 1);
  assert.equal(calls[0].options.mediaType, 'image');
  assert.equal(calls[0].options.removeBackground, true);
});

test('vv command returns a media payload from a view-once image message', async () => {
  const reply = await executeCommand('.vv', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer(media, mediaType) {
      assert.equal(mediaType, 'image');
      return Buffer.from('view-once-image');
    },
  }, {
    imageMessage: {
      viewOnce: true,
      url: 'https://example.com/photo.jpg',
    },
  });

  assert.equal(reply.type, 'view-once');
  assert.equal(reply.mediaType, 'image');
  assert.ok(Buffer.isBuffer(reply.mediaBuffer));
  assert.equal(reply.mediaBuffer.toString('utf8'), 'view-once-image');
});

test('vv command carries an optional caption text', async () => {
  const reply = await executeCommand('.vv caption contoh', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async downloadQuotedMediaBuffer() {
      return Buffer.from('view-once-image');
    },
  }, {
    imageMessage: {
      viewOnce: true,
      url: 'https://example.com/photo.jpg',
    },
  });

  assert.equal(reply.type, 'view-once');
  assert.equal(reply.caption, 'caption contoh');
});

test('qr command returns a high-quality qr image payload', async () => {
  const reply = await executeCommand('.qr hello world', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'qrcode');
  assert.ok(Buffer.isBuffer(reply.imageBuffer));
  assert.equal(reply.mimetype, 'image/png');
  assert.equal(reply.caption, 'hello world');
});

test('ss command returns a screenshot image payload', async () => {
  const calls = [];
  const reply = await executeCommand('.ss example.com', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
    async fetchScreenshotBuffer(targetUrl, options) {
      calls.push({ targetUrl, options });
      return Buffer.from('fake-screenshot');
    },
  });

  assert.equal(reply.type, 'screenshot');
  assert.ok(Buffer.isBuffer(reply.imageBuffer));
  assert.equal(reply.imageBuffer.toString('utf8'), 'fake-screenshot');
  assert.equal(reply.caption, 'https://example.com/');
  assert.equal(calls.length, 1);
  assert.equal(calls[0].targetUrl, 'https://example.com/');
});

test('ss command rejects missing link', async () => {
  const reply = await executeCommand('.ss', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'screenshot');
  assert.equal(reply.imageBuffer, null);
  assert.match(reply.caption, /Sila isi link/i);
});

test('txt command returns a text document payload', async () => {
  const reply = await executeCommand('.txt hello world', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'document');
  assert.ok(Buffer.isBuffer(reply.document));
  assert.equal(reply.fileName, 'document.txt');
  assert.equal(reply.mimetype, 'text/plain');
  assert.equal(reply.document.toString('utf8'), 'hello world');
});

test('txt command preserves multiline content from current text', async () => {
  const source = '.txt Baris 1\nBaris 2\n\nBaris 4';
  const reply = await executeCommand(source, {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'document');
  assert.equal(reply.fileName, 'document.txt');
  assert.equal(reply.document.toString('utf8'), 'Baris 1\nBaris 2\n\nBaris 4');
});

test('csv command returns a csv document payload', async () => {
  const reply = await executeCommand('.csv name,phone\\nAli,60123456789', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'document');
  assert.ok(Buffer.isBuffer(reply.document));
  assert.equal(reply.fileName, 'document.csv');
  assert.equal(reply.mimetype, 'text/csv');
});

test('md command returns a markdown document payload', async () => {
  const reply = await executeCommand('.md # Laporan Hari Ini', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'document');
  assert.ok(Buffer.isBuffer(reply.document));
  assert.equal(reply.fileName, 'document.md');
  assert.equal(reply.mimetype, 'text/markdown');
  assert.equal(reply.document.toString('utf8'), '# Laporan Hari Ini');
});

test('md command preserves multiline markdown from current text', async () => {
  const source = '.md # Tajuk\n\n- Item 1\n- Item 2';
  const reply = await executeCommand(source, {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'document');
  assert.equal(reply.fileName, 'document.md');
  assert.equal(reply.document.toString('utf8'), '# Tajuk\n\n- Item 1\n- Item 2');
});

test('pdf command returns a pdf document payload with permit caption', async () => {
  const reply = await executeCommand('.pdf hello world', {
    commandPrefix: '.',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'document');
  assert.ok(Buffer.isBuffer(reply.document));
  assert.equal(reply.fileName, 'document.pdf');
  assert.equal(reply.mimetype, 'application/pdf');
  assert.equal(reply.caption, 'Permit for this site');
});

test('unknown command returns command-not-found payload with shared web link', async () => {
  const reply = await executeCommand('.doesnotexist test', {
    commandPrefix: '.',
    appBaseUrl: 'https://routebot.example.com',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'command-not-found');
  assert.equal(reply.commandPrefix, '.');
  assert.equal(reply.openInWebUrl, 'https://routebot.example.com/#page=bot-command&shared=bot-command');
  assert.match(reply.text, /Command not found\./i);
});

test('unknown command shared web link keeps subpath and opens hash page correctly', async () => {
  const reply = await executeCommand('.doesnotexist test', {
    commandPrefix: '.',
    appBaseUrl: 'https://routebot.example.com/app',
    http: {
      async get() {
        throw new Error('not used');
      },
    },
  });

  assert.equal(reply.type, 'command-not-found');
  assert.equal(reply.openInWebUrl, 'https://routebot.example.com/app/#page=bot-command&shared=bot-command');
  assert.equal(
    reply.text,
    ['Command not found.', '', 'Klik button di bawah untuk lihat semua command:'].join('\n'),
  );
});